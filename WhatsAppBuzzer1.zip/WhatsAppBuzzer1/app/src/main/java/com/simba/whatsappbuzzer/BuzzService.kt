package com.simba.whatsappbuzzer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat

/**
 * Keeps re-alerting (vibration + heads-up notification + sound) on a
 * repeating interval until it is explicitly stopped - either because
 * WhatsAppNotificationListener detected the original message was opened,
 * or because the user tapped "I've seen it" on the buzz notification.
 */
class BuzzService : Service() {

    companion object {
        const val ACTION_START = "com.simba.whatsappbuzzer.action.START"
        const val ACTION_STOP = "com.simba.whatsappbuzzer.action.STOP"
        const val EXTRA_CHAT_NAME = "extra_chat_name"

        private const val FOREGROUND_CHANNEL_ID = "buzz_foreground_channel"
        private const val ALERT_CHANNEL_ID = "buzz_alert_channel"
        private const val FOREGROUND_NOTIF_ID = 1001
        private const val ALERT_NOTIF_ID = 1002
    }

    private val handler = Handler(Looper.getMainLooper())
    private var runnable: Runnable? = null
    private var chatName: String = "chat"

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopBuzzing()
                return START_NOT_STICKY
            }
            else -> {
                chatName = intent?.getStringExtra(EXTRA_CHAT_NAME) ?: chatName
                startForeground(FOREGROUND_NOTIF_ID, buildForegroundNotification())
                startBuzzLoop()
            }
        }
        return START_STICKY
    }

    private fun startBuzzLoop() {
        // Cancel any previous loop before starting a fresh one.
        runnable?.let { handler.removeCallbacks(it) }

        val intervalMs = Prefs.intervalSeconds(applicationContext).toLong() * 1000L

        runnable = object : Runnable {
            override fun run() {
                fireAlert()
                handler.postDelayed(this, intervalMs)
            }
        }
        // Fire immediately, then repeat.
        handler.post(runnable!!)
    }

    private fun fireAlert() {
        vibrate()
        showAlertNotification()
    }

    private fun vibrate() {
        val pattern = longArrayOf(0, 500, 200, 500, 200, 500)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        }
    }

    private fun showAlertNotification() {
        val stopIntent = Intent(this, BuzzService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openWhatsAppIntent = packageManager.getLaunchIntentForPackage("com.whatsapp")
        val openPendingIntent = openWhatsAppIntent?.let {
            PendingIntent.getActivity(
                this, 1, it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val customUriString = Prefs.ringtoneUri(this)
val soundUri = if (customUriString != null) {
    android.net.Uri.parse(customUriString)
} else {
    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
}

        val builder = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Still unread: $chatName")
            .setContentText("You haven't opened this chat yet. Tap to open WhatsApp.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(soundUri)
            .setAutoCancel(true)
            .addAction(0, "I've seen it", stopPendingIntent)

        if (openPendingIntent != null) {
            builder.setContentIntent(openPendingIntent)
        }

        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(ALERT_NOTIF_ID, builder.build())
    }

    private fun stopBuzzing() {
        runnable?.let { handler.removeCallbacks(it) }
        runnable = null
        val nm = getSystemService(NotificationManager::class.java)
        nm.cancel(ALERT_NOTIF_ID)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildForegroundNotification() =
        NotificationCompat.Builder(this, FOREGROUND_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Watching \"$chatName\"")
            .setContentText("Buzzing until you open this chat in WhatsApp.")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)

        val fgChannel = NotificationChannel(
            FOREGROUND_CHANNEL_ID, "Watcher status",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(fgChannel)

        val alertChannel = NotificationChannel(
            ALERT_CHANNEL_ID, "Unread chat alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(true)
            description = "Repeats until you open the tracked WhatsApp chat"
        }
        nm.createNotificationChannel(alertChannel)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        runnable?.let { handler.removeCallbacks(it) }
        super.onDestroy()
    }
}
