# WhatsApp Buzzer

An Android app that watches for notifications from **one specific WhatsApp chat**
and keeps re-alerting (vibration + repeated notification) every N minutes until
you actually open that chat in WhatsApp.

**Android only.** iOS does not allow any third-party app to read another app's
notification content, so this approach isn't possible on iPhone — that's an
Apple platform restriction, not a limitation of this project.

## How it works

1. `WhatsAppNotificationListener` is a `NotificationListenerService` that gets
   told about every notification on your phone. It ignores everything except
   notifications from the WhatsApp package whose title matches the chat name
   you configure.
2. When a match comes in, it starts `BuzzService`, a foreground service that
   vibrates and re-posts a heads-up notification every X minutes.
3. WhatsApp automatically removes its own notification the moment you open
   that chat. The listener detects that removal and stops the buzzing
   automatically. You can also tap "I've seen it" on the buzz notification to
   stop it manually.

## Build & install

You'll need [Android Studio](https://developer.android.com/studio) (free).

1. Unzip the project.
2. Open the folder in Android Studio (`File > Open`).
3. Let Gradle sync (first time may take a few minutes to download dependencies).
4. Connect your Android phone via USB with USB debugging enabled, or use an
   emulator (emulators can't receive real WhatsApp notifications, so a real
   phone is recommended).
5. Click Run ▶. This installs the app on your phone.

Alternatively, in a terminal with the Android SDK set up:

```
./gradlew assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk` — copy it to
your phone and install it (you'll need to allow "install unknown apps" for
whatever app you transfer it with).

## Setup on your phone

1. Open the app.
2. Tap **"Grant notification access"** → find "WhatsApp Buzzer" in the list →
   turn it on. This is required for the app to see any notifications at all.
3. Tap **"Exempt from battery optimization"** → set battery usage to
   "Unrestricted". Without this, Android may kill the background service
   after a while and the repeat alerts will stop firing.
4. Enter the **exact** chat or contact name as it appears in WhatsApp (e.g.
   `Mom`, or the exact group name). Matching is case-insensitive but must be
   a substring match against the notification title.
5. Set how often you want to be re-buzzed, in minutes.
6. Turn on the **Enabled** switch and tap **Save**.

Now, whenever that specific chat sends you a message, your phone will buzz
and re-notify every N minutes until you open the chat in WhatsApp (or tap
"I've seen it").

## Limitations / things to know

- Only works for one chat name at a time in this version — enter one
  name, and any incoming chat whose title contains that text will trigger it.
  (If you want multiple chats tracked independently, that's a straightforward
  extension — see "Next steps" below.)
- The app reads only the *title* of WhatsApp notifications to match against
  your configured chat name — it does not read or store message content, and
  nothing leaves your device.
- Android may still delay or batch notifications under aggressive battery
  savers (some phone brands, e.g. Xiaomi, Huawei, Oppo, are notorious for
  this) — the battery optimization exemption step above is important.
- WhatsApp must actually deliver a notification for this to trigger; if
  WhatsApp's own notifications are muted for that chat, this app won't see
  anything either.

## Next steps you could add

- Support tracking multiple chats, each with its own interval.
- A quieter "escalating" pattern (start gentle, get louder/faster over time).
- A log/history screen showing when alerts fired and when they were cleared.

Let me know if you'd like me to add any of these.
