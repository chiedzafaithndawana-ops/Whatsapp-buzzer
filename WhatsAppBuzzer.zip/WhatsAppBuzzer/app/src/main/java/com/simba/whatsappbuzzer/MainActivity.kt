package com.simba.whatsappbuzzer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.simba.whatsappbuzzer.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.editChatName.setText(Prefs.chatName(this))
        binding.editInterval.setText(Prefs.intervalMinutes(this).toString())
        binding.switchEnabled.isChecked = Prefs.isEnabled(this)

        binding.btnGrantAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        binding.btnBatteryOptimization.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't open settings", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnSave.setOnClickListener {
            saveSettings()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100
                )
            }
        }

        updateStatusText()
    }

    override fun onResume() {
        super.onResume()
        updateStatusText()
    }

    private fun saveSettings() {
        val name = binding.editChatName.text.toString().trim()
        val interval = binding.editInterval.text.toString().toIntOrNull() ?: 5

        if (name.isEmpty()) {
            Toast.makeText(this, "Enter the exact chat/contact name as it appears in WhatsApp", Toast.LENGTH_LONG).show()
            return
        }
        if (!isListenerEnabled()) {
            Toast.makeText(this, "Please grant notification access first", Toast.LENGTH_LONG).show()
            return
        }

        Prefs.setChatName(this, name)
        Prefs.setIntervalMinutes(this, interval.coerceAtLeast(1))
        Prefs.setEnabled(this, binding.switchEnabled.isChecked)

        Toast.makeText(this, "Saved. Watching \"$name\" every $interval min.", Toast.LENGTH_SHORT).show()
    }

    private fun isListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(packageName)
    }

    private fun updateStatusText() {
        binding.textPermissionStatus.text = if (isListenerEnabled()) {
            "Notification access: granted"
        } else {
            "Notification access: NOT granted - tap below"
        }
    }
}
