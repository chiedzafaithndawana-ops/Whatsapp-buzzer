package com.simba.whatsappbuzzer

import android.content.Context

/**
 * Small wrapper around SharedPreferences holding the user's chosen
 * chat name, buzz interval, and whether tracking is enabled.
 */
object Prefs {
    private const val FILE = "wa_buzzer_prefs"
    private const val KEY_CHAT_NAME = "chat_name"
    private const val KEY_INTERVAL_MIN = "interval_min"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_ACTIVE_KEY = "active_notification_key"

    fun chatName(context: Context): String =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_CHAT_NAME, "") ?: ""

    fun setChatName(context: Context, name: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_CHAT_NAME, name).apply()
    }

    fun intervalMinutes(context: Context): Int =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getInt(KEY_INTERVAL_MIN, 5)

    fun setIntervalMinutes(context: Context, minutes: Int) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putInt(KEY_INTERVAL_MIN, minutes).apply()
    }

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun activeNotificationKey(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_KEY, null)

    fun setActiveNotificationKey(context: Context, key: String?) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_ACTIVE_KEY, key).apply()
    }
}
