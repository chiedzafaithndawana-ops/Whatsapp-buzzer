package com.simba.whatsappbuzzer

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * System-wide notification listener. Only WhatsApp (and WhatsApp Business)
 * notifications whose title matches the chat name the user configured are
 * acted on. Everything else is ignored.
 *
 * When a matching notification appears -> start the repeating BuzzService.
 * When that same notification later disappears (WhatsApp clears it the
 * moment the user opens the chat) -> stop the BuzzService, since that is
 * the clearest signal the user has actually seen it.
 */
class WhatsAppNotificationListener : NotificationListenerService() {

    private val whatsAppPackages = setOf("com.whatsapp", "com.whatsapp.w4b")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.isEnabled(applicationContext)) return
        if (sbn.packageName !in whatsAppPackages) return

        // Skip WhatsApp's own summary/group notifications, which have no
        // useful title, and skip our own buzz notifications.
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        if (title.isBlank()) return

        val target = Prefs.chatName(applicationContext).trim()
        if (target.isEmpty()) return

        if (title.contains(target, ignoreCase = true)) {
            Prefs.setActiveNotificationKey(applicationContext, sbn.key)
            val intent = Intent(this, BuzzService::class.java).apply {
                action = BuzzService.ACTION_START
                putExtra(BuzzService.EXTRA_CHAT_NAME, title)
            }
            startForegroundService(intent)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val activeKey = Prefs.activeNotificationKey(applicationContext) ?: return
        if (sbn.key == activeKey) {
            // The original WhatsApp notification is gone -> user opened the chat.
            Prefs.setActiveNotificationKey(applicationContext, null)
            val intent = Intent(this, BuzzService::class.java).apply {
                action = BuzzService.ACTION_STOP
            }
            startService(intent)
        }
    }
}
